package entity

open class Weapon {
    var damage : Int = 0
    lateinit var name : String
}