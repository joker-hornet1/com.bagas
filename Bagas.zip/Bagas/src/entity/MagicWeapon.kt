package entity

class MagicWeapon : Weapon() {
    var magicDamage : Int = 0
}